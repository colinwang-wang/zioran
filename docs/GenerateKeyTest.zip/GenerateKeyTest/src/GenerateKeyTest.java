import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import com.daimler.security.interfaces.Parameter;
import com.daimler.security.generated.GW223_19_04_01_20195225025204;
import com.daimler.security.generated.GW223_18_22_01_20185329105359;
import com.daimler.security.generated.EZS167_20_42_59_20200717030759;
import com.daimler.security.generated.EZS223_18_14_04_20180006090035;
import com.daimler.security.generated.EZS223_18_14_02_20180305110356;
import javax.crypto.NoSuchPaddingException;



public class GenerateKeyTest {
	
	private static Byte[] hexToByte(String hex){
        int m = 0, n = 0;
        int byteLen = hex.length() / 2; // ÿ�����ַ�����һ���ֽ�
        Byte[] ret = new Byte[byteLen];
        for (int i = 0; i < byteLen; i++) {
            m = i * 2 + 1;
            n = m + 1;
            int intVal = Integer.decode("0x" + hex.substring(i * 2, m) + hex.substring(m, n));
            ret[i] = Byte.valueOf((byte)intVal);
        }
        return ret;
    }
	
	private static String bytesToHex(final Byte[] b) {
        final char[] hexDigit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        final StringBuffer buf = new StringBuffer(2 * b.length);
        for (int i = 0; i < b.length; ++i) {
            buf.append(hexDigit[(b[i] & 0xF0) >> 4]);
            buf.append(hexDigit[b[i] & 0xF]);
        }
        return buf.toString();
    }
	
	public static void main(String[] args) throws IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException {
		
		String seedStr = "11867B83455325D9F403D286F08D2CAD93F4A71FCAA496D02774316CE8473251";
		seedStr = seedStr.replace(",", "");
		System.out.println("SEED:"+seedStr);
		
		
		Byte[] iSeedArray = hexToByte(seedStr);
		int securityLevel = 17;
		Byte[] ioKeyArray = new Byte[64];
		Parameter<Integer> oActualKeyArraySize = new Parameter<>(1);

		/*
		GW223_19_04_01_20195225025204 gw223_19 = new GW223_19_04_01_20195225025204();
		gw223_19.GenerateKey(iSeedArray,securityLevel,null,null,ioKeyArray,oActualKeyArraySize);
		System.out.println("GW223_19 KEY:"+bytesToHex(ioKeyArray));

		
		GW223_18_22_01_20185329105359 gw223_18 = new GW223_18_22_01_20185329105359();
		gw223_18.GenerateKey(iSeedArray,securityLevel,null,null,ioKeyArray,oActualKeyArraySize);
		System.out.println("GW223_18 KEY:"+bytesToHex(ioKeyArray));
		*/
		EZS223_18_14_02_20180305110356 ezs223_18 = new EZS223_18_14_02_20180305110356();
		ezs223_18.GenerateKey(iSeedArray,securityLevel,null,null,ioKeyArray,oActualKeyArraySize);
		System.out.println("EZS223_18 KEY:"+bytesToHex(ioKeyArray));
		/*
		EZS167_20_42_59_20200717030759 ezs167 = new EZS167_20_42_59_20200717030759();
		ezs167.GenerateKey(iSeedArray,59,null,null,ioKeyArray,oActualKeyArraySize);
		System.out.println("EZS167_3B KEY:"+bytesToHex(ioKeyArray));
		*/
	}
}
